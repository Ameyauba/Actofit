Folder structure:
-----------------
Models:
userModel
EmployeeModel

Controller:
userController

Routes:
userRoutes

Postman:
postman file.

As mentioned, created 2 collections Users and Employees, with the fields expected.
1. Registration page: firstName,lastName,Email,Mobile,Password to User Collection and
   employee id and organisation name from Employee collection.
2. Login page: emailid or mobile number with password is passed for login.
3. List user: 2 get APIs 
		1. search employee. 
		2. sort employee with paging limit used.