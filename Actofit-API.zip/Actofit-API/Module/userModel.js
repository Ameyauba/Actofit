const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String, trim: true, index: true, unique: true, sparse: true },
    mobile: { type: String, unique: true },
    password: { type: String },
    jwt: { type: String },
    createdAt: { type: Date,  default: Date.now() },
    modifiedAt: { type: Date,  default: Date.now() },
    isActive: { type: Boolean,  default: true },
    isDeleted: { type: Boolean,  default: false },
});

module.exports = mongoose.model('user', userSchema);