const mongoose = require('mongoose');

const employeeSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    firstName: { type: String },
    lastName: { type: String },
    email: { type: String },
    mobile: { type: String },
    organisationName: {	type: String },
    userid: {type:mongoose.Schema.Types.ObjectId, ref:'user'},
    createdBy: {type:mongoose.Schema.Types.ObjectId, ref:'user'},
    modifiedBy: {type:mongoose.Schema.Types.ObjectId, ref:'user'},
    createdAt: { type: Date, required: true, default: Date.now() },
    modifiedAt: { type: Date, required: true, default: Date.now() },
    isActive: { type: Boolean, required: true, default: true },
    isDeleted: { type: Boolean, required: true, default: false },
});

module.exports = mongoose.model('employee', employeeSchema);