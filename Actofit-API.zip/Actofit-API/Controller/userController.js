const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");
const User = require('../Module/userModel');
const Employee = require('../Module/employeeModel');

exports.registerUser = (req,res,next)=>{
    User.find({email:req.body.email})
    .then(resp=>{
        if(resp.length > 0){
            res.status(409).json({
                message:'Email already exist'
            })
        }else{
            User.find({mobile:req.body.mobile})
            .then(result=>{
                if(resp.length > 0){
                    res.status(409).json({
                        message:'Mobile already exist'
                    })
                } else{
                    bcrypt.hash(req.body.password,10,(err,hash)=>{
                        if(err){
                            res.status(500).json({
                                message:'Password not encrypted'
                            })
                        }else{
                            const user = new User({
                                _id: new mongoose.Types.ObjectId,
                                firstName:req.body.firstName,
                                lastName:req.body.lastName,
                                email:req.body.email,
                                mobile:req.body.mobile,
                                password:hash
                                
                            })
                            user.save().then(result=>{
                                var employee = new Employee({
                                    _id:new mongoose.Types.ObjectId,
                                    userid:result._id,
                                    firstName:result.firstName,
                                    lastName:result.lastName,
                                    email:result.email,
                                    mobile:result.mobile,
                                    organisationName:req.body.organisationName 
                                })
                                employee.save().then(result=>{
                                    res.status(200).json({
                                        message:'User data save ',
                                        data:user
                                    })
                                    }).catch(err=>{
                                    return err
                                    })
                            }).catch(err=>{
                                return err
                            })
                        }
                    })
                }
            }).catch(err=>{
                return err
            })
        }
    })
}

exports.loginUser = (req,res,next)=>{
    User.find({$or:[{email:req.body.user_id},{mobile:req.body.user_id}]})
    .then(resp=>{
        if(resp.length != 1){
            res.status(409).json({
                message:'Please enter valid email or mobile'
            })
        }else{
            bcrypt.compare(req.body.password,resp[0].password,(err,sucess)=>{
                if(!sucess){
                    res.status(422).json({
                        message:'Incorrect Password'
                    })
                }
                    return res.status(200).json({
                        message: "user successfully logged in",
                        data: resp
                    })
                
            })

        }

    }).catch(err=>{
        res.status(500).json({
            error:err
        }) 

    })
}
    
exports.searchEmployee = (req,res,next)=>{
    
    Employee.find(
        { 
            firstName: req.query.firstName,
            lastName: req.query.lastName,
            email: req.query.email,
            mobile: req.query.mobile,
            _id:req.query.employeeId
        }
    )
    .then(resp=>{
        if(resp.length == null){
            res.status(404).json({
                error:'There is no data'
            })
        } else{
            res.status(200).json({
                Employee:resp
            })
        }

    })
    .catch(err=>{
        res.status(500).json({
            error:err
        })
    })
}

exports.sortEmployee = (req, res, next) => {
    Employee.find({})
    .sort({firstName : 1,lastName : 1,_id : 1,organisationName : 1})
    .limit(5)
    .then(resp => {
            if (resp.length == 0) {
                return res.status(204).json('No Employees')
            }
            else {
                res.status(200).json({
                    message: 'Employees Data',
                    data: resp
                })
            }
        }).catch(err => {
            res.status(500).json({
                message: 'something wrong', error: err
            })
        })

}






















    
    

